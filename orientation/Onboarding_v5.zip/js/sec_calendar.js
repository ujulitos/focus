function activaSeccionCalendar() {
    console.log('seccionCalendar');

    $('.subname1_txt').text('');
    $('.subname2_txt').text('');




    ajustaTamano();


    // window.onresize = function() {

    //     var elVPWidth = $(document).width();
    //     var elSeccWidth = $(".seccion").width();
    //     console.log(elVPWidth, elSeccWidth);

    //     if ((elSeccWidth + 110) < elVPWidth) {
    //         $("#table_calendar").addClass('condensed');
    //         // $("#table_calendar").css({
    //         //     'font-size': '10px'
    //         // });
    //     } else {
    //         $("#table_calendar").removeClass('condensed');
    //         // $("#table_calendar").css({
    //         //     'font-size': '14px'
    //         // });
    //     }

    // }

}